SMARTREVISION AI - RUN GUIDE

1. Open this folder in VS Code.
2. Make a copy of .env.example and rename it to .env.
3. Put your Gemini API key in GEMINI_API_KEY.
4. Put your MySQL root password in MYSQL_PASSWORD.
5. Install packages:
   py -m pip install -r requirements.txt
6. Make sure MySQL Server is running.
7. Start the website:
   py app.py
8. Open:
   http://127.0.0.1:5000

IMPORTANT:
- The app automatically creates the SmartRevisionAI database and tables.
- Passwords are stored as secure password hashes, not plain text.
- .env must never be uploaded to GitHub.
- Login history stores account ID/email and login time.
