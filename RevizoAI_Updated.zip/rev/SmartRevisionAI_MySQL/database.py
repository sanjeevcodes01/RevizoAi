import os
import mysql.connector
from dotenv import load_dotenv

load_dotenv()

HOST = os.getenv("MYSQL_HOST", "127.0.0.1")
PORT = int(os.getenv("MYSQL_PORT", "3306"))
USER = os.getenv("MYSQL_USER", "root")
PASSWORD = os.getenv("MYSQL_PASSWORD", "")
DATABASE = os.getenv("MYSQL_DATABASE", "SmartRevisionAI")


def server_connection():
    return mysql.connector.connect(
        host=HOST,
        port=PORT,
        user=USER,
        password=PASSWORD,
    )


def get_connection():
    return mysql.connector.connect(
        host=HOST,
        port=PORT,
        user=USER,
        password=PASSWORD,
        database=DATABASE,
    )


def create_tables():
    conn = server_connection()
    cur = conn.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS `{DATABASE}`")
    cur.close()
    conn.close()

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(190) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Upgrade an older SmartRevisionAI database if it already exists.
    try:
        cur.execute("ALTER TABLE users ADD COLUMN password_hash VARCHAR(255) NOT NULL DEFAULT ''")
    except mysql.connector.Error as exc:
        if exc.errno != 1060:
            raise

    cur.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            topic VARCHAR(255) NOT NULL,
            duration INT DEFAULT 0,
            questions INT DEFAULT 0,
            correct INT DEFAULT 0,
            accuracy DECIMAL(5,2) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS login_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            email VARCHAR(190) NOT NULL,
            ip_address VARCHAR(45),
            login_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    conn.commit()
    cur.close()
    conn.close()


def get_user_by_email(email):
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM users WHERE email=%s LIMIT 1", (email,))
    user = cur.fetchone()
    cur.close()
    conn.close()
    return user


def get_or_create_user(name, email, password_hash):
    user = get_user_by_email(email)
    if user:
        return user["id"]

    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO users (name, email, password_hash) VALUES (%s, %s, %s)",
        (name, email, password_hash),
    )
    conn.commit()
    user_id = cur.lastrowid
    cur.close()
    conn.close()
    return user_id


def record_login(user_id, email, ip_address):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO login_history (user_id, email, ip_address) VALUES (%s, %s, %s)",
        (user_id, email, ip_address),
    )
    conn.commit()
    cur.close()
    conn.close()


def save_session(user_id, topic, duration, questions, correct, accuracy):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO sessions
        (user_id, topic, duration, questions, correct, accuracy)
        VALUES (%s, %s, %s, %s, %s, %s)
        """,
        (user_id, topic, duration, questions, correct, accuracy),
    )
    conn.commit()
    cur.close()
    conn.close()


def get_user_sessions(user_id):
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute(
        """
        SELECT topic, duration, questions, correct, accuracy, created_at
        FROM sessions
        WHERE user_id=%s
        ORDER BY created_at DESC
        LIMIT 30
        """,
        (user_id,),
    )
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows


def get_login_history(limit=50):
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute(
        """
        SELECT u.name, h.email, h.login_at
        FROM login_history h
        JOIN users u ON u.id=h.user_id
        ORDER BY h.login_at DESC
        LIMIT %s
        """,
        (limit,),
    )
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows


def get_dashboard_stats(user_id):
    conn = get_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute("SELECT COUNT(*) AS total_sessions FROM sessions WHERE user_id=%s", (user_id,))
    total_sessions = cur.fetchone()["total_sessions"]

    cur.execute(
        """
        SELECT
            COALESCE(SUM(duration), 0) AS total_time,
            COALESCE(SUM(questions), 0) AS total_questions,
            COALESCE(SUM(correct), 0) AS total_correct
        FROM sessions
        WHERE user_id=%s
        """,
        (user_id,),
    )
    row = cur.fetchone()

    total_questions = int(row["total_questions"] or 0)
    total_correct = int(row["total_correct"] or 0)
    accuracy = round((total_correct / total_questions) * 100, 2) if total_questions else 0

    cur.close()
    conn.close()

    return {
        "total_sessions": total_sessions,
        "total_time": int(row["total_time"] or 0),
        "total_questions": total_questions,
        "accuracy": accuracy,
    }
