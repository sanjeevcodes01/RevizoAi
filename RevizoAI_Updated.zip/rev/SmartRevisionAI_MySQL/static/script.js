let material = "";
let questions = [];
let currentIndex = 0;
let correctCount = 0;
let answeredCount = 0;
let endTime = 0;
let startTime = 0;
let totalDurationMinutes = 0;
let timerId = null;
let weakConcepts = {};
let usedQuestions = new Set();
let sessionFinished = false;

function applySavedTheme() {
    const saved = localStorage.getItem("revizo-theme") || "dark";
    document.body.setAttribute("data-theme", saved);
    const button = document.getElementById("themeToggle");
    if (button) button.textContent = saved === "light" ? "☀️ Day" : "🌙 Night";
}

function toggleTheme() {
    const current = document.body.getAttribute("data-theme") || "dark";
    const next = current === "dark" ? "light" : "dark";
    document.body.setAttribute("data-theme", next);
    localStorage.setItem("revizo-theme", next);
    const button = document.getElementById("themeToggle");
    if (button) button.textContent = next === "light" ? "☀️ Day" : "🌙 Night";
}

document.addEventListener("DOMContentLoaded", applySavedTheme);

function updateCustomTimeVisibility() {
    const select = document.getElementById("timeSelect");
    const box = document.getElementById("customTimeBox");
    if (!select || !box) return;
    box.classList.toggle("hidden", select.value !== "custom");
}

function getSelectedDuration() {
    const value = document.getElementById("timeSelect").value;
    if (value !== "custom") return Number(value);

    const hours = Math.max(0, Number(document.getElementById("customHours").value || 0));
    const minutes = Math.max(0, Number(document.getElementById("customMinutes").value || 0));
    const total = hours * 60 + minutes;

    if (!Number.isFinite(total) || total < 1) {
        throw new Error("Please enter at least 1 minute for custom time.");
    }
    if (minutes > 59) {
        throw new Error("Custom minutes must be between 0 and 59.");
    }
    return total;
}

async function readPDF() {
    const file = document.getElementById("pdfFile").files[0];
    const status = document.getElementById("pdfStatus");
    if (!file) {
        status.textContent = "Please select a PDF first.";
        return;
    }

    status.textContent = "Reading PDF...";
    const formData = new FormData();
    formData.append("pdf", file);

    try {
        const res = await fetch("/extract_pdf", { method: "POST", body: formData });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Could not read PDF.");
        document.getElementById("material").value = data.text;
        status.textContent = "PDF text loaded successfully.";
    } catch (err) {
        status.textContent = err.message;
    }
}

async function getQuestions() {
    const difficulty = Object.keys(weakConcepts).length ? "easy" : "medium";
    const response = await fetch("/generate_quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            material,
            weak_concepts: weakConcepts,
            previous_questions: Array.from(usedQuestions),
            difficulty
        })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Quiz generation failed.");
    return data.questions || [];
}

async function startPractice() {
    material = document.getElementById("material").value.trim();
    if (!material) {
        alert("Please enter your study material or read a PDF.");
        return;
    }

    let minutes;
    try {
        minutes = getSelectedDuration();
    } catch (err) {
        alert(err.message);
        return;
    }

    document.getElementById("startBtn").disabled = true;
    document.getElementById("startBtn").textContent = "Preparing questions...";

    try {
        questions = await getQuestions();
        currentIndex = 0;
        correctCount = 0;
        answeredCount = 0;
        weakConcepts = {};
        usedQuestions = new Set();
        sessionFinished = false;
        totalDurationMinutes = minutes;
        startTime = Date.now();
        endTime = startTime + minutes * 60 * 1000;

        document.querySelector(".practice-card").classList.add("hidden");
        document.getElementById("quizSection").classList.remove("hidden");

        timerId = setInterval(updateTimer, 1000);
        updateTimer();
        renderQuestion();
    } catch (err) {
        alert(err.message);
        document.getElementById("startBtn").disabled = false;
        document.getElementById("startBtn").textContent = "START PRACTICE";
    }
}

function updateTimer() {
    if (!endTime || sessionFinished) return;
    const remaining = Math.max(0, endTime - Date.now());
    const totalSeconds = Math.floor(remaining / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const min = Math.floor((totalSeconds % 3600) / 60);
    const sec = totalSeconds % 60;
    const text = hours > 0
        ? `${String(hours).padStart(2, "0")}:${String(min).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
        : `${String(min).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
    document.getElementById("timer").textContent = text;

    if (remaining <= 0) finishPractice("Time is up. Your session has been completed automatically.");
}

function renderQuestion() {
    if (Date.now() >= endTime) {
        finishPractice("Time is up. Your session has been completed automatically.");
        return;
    }

    if (currentIndex >= questions.length) {
        loadMoreQuestions();
        return;
    }

    const q = questions[currentIndex];
    usedQuestions.add(q.question);

    document.getElementById("progressText").textContent =
        `Question ${answeredCount + 1}`;
    document.getElementById("progressFill").style.width =
        `${Math.min(100, (answeredCount % 10) * 10 + 10)}%`;

    document.getElementById("questionBox").innerHTML = `
        <div class="question-card">
            <h2>${escapeHtml(q.question)}</h2>
            <div class="options">
                ${q.options.map((opt, i) => `
                    <button class="option" onclick="answerQuestion(${i})">
                        <span>${String.fromCharCode(65 + i)}</span>${escapeHtml(opt)}
                    </button>
                `).join("")}
            </div>
        </div>
    `;
    document.getElementById("resultBox").innerHTML = "";
}

async function answerQuestion(selected) {
    if (sessionFinished) return;
    const q = questions[currentIndex];
    const buttons = [...document.querySelectorAll(".option")];
    buttons.forEach(btn => btn.disabled = true);

    const isCorrect = selected === Number(q.answer);
    answeredCount++;

    if (isCorrect) {
        correctCount++;
        delete weakConcepts[q.concept];
    } else {
        weakConcepts[q.concept] = (weakConcepts[q.concept] || 0) + 1;
    }

    buttons.forEach((btn, i) => {
        if (i === Number(q.answer)) btn.classList.add("correct");
        if (i === selected && !isCorrect) btn.classList.add("wrong");
    });

    document.getElementById("resultBox").innerHTML = `
        <div class="answer-result ${isCorrect ? "success" : "danger"}">
            <b>${isCorrect ? "Correct! 🎉" : "Not quite."}</b>
            <p>Correct answer: ${escapeHtml(q.options[q.answer])}</p>
            <small>${escapeHtml(q.explanation)}</small>
            <button class="btn btn-primary" onclick="nextQuestion()">Next →</button>
        </div>
    `;
}

async function nextQuestion() {
    if (sessionFinished) return;
    currentIndex++;
    if (currentIndex >= questions.length) {
        try {
            document.getElementById("resultBox").innerHTML = "<p class='muted'>Generating the next set...</p>";
            questions = await getQuestions();
            currentIndex = 0;
        } catch (err) {
            finishPractice(err.message);
            return;
        }
    }
    renderQuestion();
}

async function loadMoreQuestions() {
    try {
        document.getElementById("questionBox").innerHTML = "<p class='muted'>Generating more questions...</p>";
        questions = await getQuestions();
        currentIndex = 0;
        renderQuestion();
    } catch (err) {
        finishPractice(err.message);
    }
}

function formatDuration(seconds) {
    const safe = Math.max(0, Math.floor(seconds));
    const h = Math.floor(safe / 3600);
    const m = Math.floor((safe % 3600) / 60);
    const s = safe % 60;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

async function finishPractice(message = "") {
    if (sessionFinished || !startTime) return;
    sessionFinished = true;
    clearInterval(timerId);

    const elapsedSeconds = Math.max(0, Math.floor((Date.now() - startTime) / 1000));
    const remainingSeconds = Math.max(0, Math.floor((endTime - Date.now()) / 1000));
    const savedMinutes = Math.max(0, Math.ceil(elapsedSeconds / 60));
    const accuracy = answeredCount ? Math.round((correctCount / answeredCount) * 10000) / 100 : 0;
    const reason = message || (remainingSeconds > 0
        ? "You ended the session before the selected time was over."
        : "Time is up. Your session has been completed automatically.");

    document.getElementById("quizSection").innerHTML = `
        <div class="result-card">
            <div class="badge">SESSION COMPLETE</div>
            <h1>Revision session completed 🎯</h1>
            <p class="muted">${escapeHtml(reason)}</p>
            <div class="result-grid">
                <div><span>Questions</span><strong>${answeredCount}</strong></div>
                <div><span>Correct</span><strong>${correctCount}</strong></div>
                <div><span>Wrong</span><strong>${answeredCount - correctCount}</strong></div>
                <div><span>Accuracy</span><strong>${accuracy}%</strong></div>
                <div><span>Time Used</span><strong>${formatDuration(elapsedSeconds)}</strong></div>
                <div><span>Time Left</span><strong>${formatDuration(remainingSeconds)}</strong></div>
            </div>
            <div class="result-actions">
                <a class="btn btn-primary" href="/dashboard">View Dashboard</a>
                <a class="btn btn-outline" href="/practice">Practice Again</a>
            </div>
        </div>
    `;

    try {
        await fetch("/save_session", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                duration: savedMinutes,
                questions: answeredCount,
                correct: correctCount,
                accuracy
            })
        });
    } catch (_) {}
}

function endSessionManually() {
    if (!sessionFinished && startTime) {
        finishPractice("You ended the session manually. Your current result has been saved.");
    }
}

function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[c]));
}
