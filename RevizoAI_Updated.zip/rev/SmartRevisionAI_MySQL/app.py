import os
import time
from datetime import datetime
from functools import wraps

import fitz
from dotenv import load_dotenv
from flask import Flask, flash, jsonify, redirect, render_template, request, session, url_for
from google import genai
from google.genai import types
from werkzeug.security import check_password_hash, generate_password_hash

from database import (
    create_tables,
    get_dashboard_stats,
    get_login_history,
    get_or_create_user,
    get_user_by_email,
    get_user_sessions,
    record_login,
    save_session,
)

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-this-secret")

MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

create_tables()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("home"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/")
def home():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")

    if not name or not email or not password:
        flash("Name, email/ID and password are required.", "error")
        return redirect(url_for("home"))

    if len(password) < 6:
        flash("Password must contain at least 6 characters.", "error")
        return redirect(url_for("home"))

    if get_user_by_email(email):
        flash("This email/ID is already registered. Please sign in.", "error")
        return redirect(url_for("home"))

    password_hash = generate_password_hash(password)
    user_id = get_or_create_user(name, email, password_hash)

    session.clear()
    session["user_id"] = user_id
    session["name"] = name
    session["email"] = email
    record_login(user_id, email, request.remote_addr)

    return redirect(url_for("dashboard"))


@app.route("/login", methods=["POST"])
def login():
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")

    user = get_user_by_email(email)

    if not user or not check_password_hash(user["password_hash"], password):
        flash("Invalid email/ID or password.", "error")
        return redirect(url_for("home"))

    session.clear()
    session["user_id"] = user["id"]
    session["name"] = user["name"]
    session["email"] = user["email"]
    record_login(user["id"], user["email"], request.remote_addr)

    return redirect(url_for("dashboard"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


def mask_email(email):
    """Hide most of the local part while keeping the account recognizable."""
    email = (email or "").strip()
    if "@" not in email:
        return email
    local, domain = email.split("@", 1)
    if len(local) <= 1:
        masked_local = local
    elif len(local) <= 4:
        masked_local = local[0] + "***"
    else:
        masked_local = local[:4] + "***"
    return f"{masked_local}@{domain}"


@app.route("/dashboard")
@login_required
def dashboard():
    user_id = session["user_id"]
    stats = get_dashboard_stats(user_id)
    sessions = get_user_sessions(user_id)
    login_history = get_login_history(limit=50)
    for item in login_history:
        item["masked_email"] = mask_email(item.get("email", ""))
    return render_template(
        "dashboard.html",
        name=session["name"],
        email=session["email"],
        masked_email=mask_email(session["email"]),
        stats=stats,
        sessions=sessions,
        login_history=login_history,
    )


@app.route("/practice")
@login_required
def practice():
    return render_template("quiz.html", name=session["name"])


@app.route("/extract_pdf", methods=["POST"])
@login_required
def extract_pdf():
    file = request.files.get("pdf")
    if not file or not file.filename.lower().endswith(".pdf"):
        return jsonify({"error": "Please select a PDF file."}), 400

    temp_path = os.path.join(UPLOAD_DIR, f"temp_{int(time.time() * 1000)}.pdf")
    try:
        file.save(temp_path)
        doc = fitz.open(temp_path)
        text = "\n".join(page.get_text() for page in doc).strip()
        doc.close()

        if not text:
            return jsonify({
                "error": "This PDF appears to be scanned/image-only. Please use a text PDF or paste the text."
            }), 400

        return jsonify({"text": text[:50000]})
    except Exception as exc:
        return jsonify({"error": f"Could not read PDF: {exc}"}), 500
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


@app.route("/generate_quiz", methods=["POST"])
@login_required
def generate_quiz():
    if not GEMINI_API_KEY:
        return jsonify({"error": "Gemini API key is missing in .env"}), 500

    data = request.get_json(silent=True) or {}
    material = (data.get("material") or "").strip()
    weak_concepts = data.get("weak_concepts") or {}
    previous_questions = data.get("previous_questions") or []
    difficulty = data.get("difficulty", "medium")

    if not material:
        return jsonify({"error": "Please enter study material first."}), 400

    material = material[:30000]
    previous = "\n".join(previous_questions[-25:])[:8000]
    weak_text = ", ".join(
        f"{k}: {v}" for k, v in weak_concepts.items()
    )[:4000]

    prompt = f"""
You are an adaptive revision quiz generator.

Use ONLY the study material below. Do not add outside facts.

Create exactly 5 NEW multiple-choice questions.
Each question must have exactly 4 options and exactly one correct answer.
Return valid JSON only.

Rules:
- Questions must be directly based on the supplied material.
- Avoid repeating previous questions.
- If weak concepts are supplied, give them extra practice.
- Difficulty: {difficulty}.
- Keep explanations short and student-friendly.

Study material:
{material}

Weak concepts:
{weak_text or "None"}

Previous questions to avoid:
{previous or "None"}
"""

    try:
        client = genai.Client(api_key=GEMINI_API_KEY)
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=types.Schema(
                    type=types.Type.OBJECT,
                    properties={
                        "questions": types.Schema(
                            type=types.Type.ARRAY,
                            items=types.Schema(
                                type=types.Type.OBJECT,
                                properties={
                                    "question": types.Schema(type=types.Type.STRING),
                                    "options": types.Schema(
                                        type=types.Type.ARRAY,
                                        items=types.Schema(type=types.Type.STRING),
                                    ),
                                    "answer": types.Schema(type=types.Type.INTEGER),
                                    "explanation": types.Schema(type=types.Type.STRING),
                                    "concept": types.Schema(type=types.Type.STRING),
                                },
                                required=[
                                    "question",
                                    "options",
                                    "answer",
                                    "explanation",
                                    "concept",
                                ],
                            ),
                        )
                    },
                    required=["questions"],
                ),
            ),
        )

        import json
        result = json.loads(response.text)
        questions = result.get("questions", [])

        clean = []
        for q in questions:
            if len(q.get("options", [])) == 4 and 0 <= int(q.get("answer", -1)) <= 3:
                clean.append(q)

        if not clean:
            return jsonify({"error": "AI did not return valid questions. Please try again."}), 502

        return jsonify({"questions": clean})
    except Exception as exc:
        return jsonify({"error": f"Quiz generation failed: {exc}"}), 503


@app.route("/save_session", methods=["POST"])
@login_required
def save_quiz_session():
    data = request.get_json(silent=True) or {}
    duration = int(data.get("duration", 0))
    questions = int(data.get("questions", 0))
    correct = int(data.get("correct", 0))
    accuracy = float(data.get("accuracy", 0))

    save_session(
        session["user_id"],
        "Adaptive Revision",
        duration,
        questions,
        correct,
        accuracy,
    )
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(debug=True)
